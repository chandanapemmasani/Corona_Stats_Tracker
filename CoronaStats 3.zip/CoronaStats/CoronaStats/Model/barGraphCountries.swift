////
////  barGraphCountries.swift
////  CoronaStats
////
////  Created by Admin on 17/05/20.
////  Copyright © 2020 Admin. All rights reserved.
////
//
//import Foundation
//
//public class Afghanistn: Codable {
//    
//     public var cases: [CasesPerDay]?
//    
//    private enum CodingKeys: String, CodingKey {
//          case cases
//    }
//
//    public required init(from decoder: Decoder) throws {
//           let container = try decoder.container(keyedBy: CodingKeys.self)
//           
//           self.cases = try container.decodeIfPresent([CasesPerDay].self, forKey: .cases)
//    }
//    public func encode(to encoder: Encoder) throws {
//           var container = encoder.container(keyedBy: CodingKeys.self)
//           if cases != nil {
//               try container.encode(cases, forKey: .cases)
//           }
//    }
//}
