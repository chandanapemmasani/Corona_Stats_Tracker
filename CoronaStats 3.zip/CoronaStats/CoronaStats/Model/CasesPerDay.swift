//
//  CasesPerDay.swift
//  CoronaStats
//
//  Created by Admin on 17/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

public class CasesPerDay: Codable {

       public var date: String?
       public var confirmed: Int?
       public var deaths: Int?
       public var recovered: Int?
    
    private enum CodingKeys: String, CodingKey {
        
        case date
               case confirmed
               case deaths
               case recovered
    }
    
    public required init(from decoder: Decoder) throws {
           let container = try decoder.container(keyedBy: CodingKeys.self)
           
           self.date = try container.decodeIfPresent(String.self, forKey: .date)
           self.confirmed = try container.decodeIfPresent(Int.self, forKey: .confirmed)
           self.deaths = try container.decodeIfPresent(Int.self, forKey: .deaths)
           self.recovered = try container.decodeIfPresent(Int.self, forKey: .recovered)
         
       }
    
    public func encode(to encoder: Encoder) throws {
           var container = encoder.container(keyedBy: CodingKeys.self)
           if date != nil {
               try container.encode(date, forKey: .date)
           }
           if confirmed != nil {
               try container.encode(confirmed, forKey: .confirmed)
           }
           if deaths != nil {
               try container.encode(deaths, forKey: .deaths)
           }
           if recovered != nil {
               try container.encode(recovered, forKey: .recovered)
         
       }
}
}
