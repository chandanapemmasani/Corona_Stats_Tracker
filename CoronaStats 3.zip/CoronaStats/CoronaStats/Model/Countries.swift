//
//  Countries.swift
//  CoronaStats
//
//  Created by Admin on 18/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

public class Countries: Codable {
    
    public var country: String?
    public var province: String?
    public var updatedAt: String?
    public var stats: Stats?
    public var coordinates: Coordinates?
    
    private enum CodingKeys: String, CodingKey {
        case country
        case province
        case updatedAt
        case stats
        case coordinates
    }
    public required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self.country = try container.decodeIfPresent(String.self, forKey: .country)
        self.province = try container.decodeIfPresent(String.self, forKey: .province)
        self.updatedAt = try container.decodeIfPresent(String.self, forKey: .updatedAt)
        self.stats = try container.decodeIfPresent(Stats.self, forKey: .stats)
        self.coordinates = try container.decodeIfPresent(Coordinates.self, forKey: .coordinates)
        
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        if country != nil {
            try container.encode(country, forKey: .country)
        }
        if province != nil {
            try container.encode(province, forKey: .province)
        }
        if updatedAt != nil {
            try container.encode(updatedAt, forKey: .updatedAt)
        }
        if stats != nil {
            try container.encode(stats, forKey: .stats)
        }
        if coordinates != nil {
            try container.encode(coordinates, forKey: .coordinates)
        }
    }
    
}
