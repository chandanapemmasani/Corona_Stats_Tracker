//
//  CommonTabBarController.swift
//  CoronaStats
//
//  Created by Admin on 01/06/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit

class CommonTabBarController: UITabBarController {

    var countriesArray = [String]()
}
