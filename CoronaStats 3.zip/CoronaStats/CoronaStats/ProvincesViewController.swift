//
//  ProvincesViewController.swift
//  CoronaStats
//
//  Created by Admin on 01/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit
import Charts

class ProvincesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var countryList = [Countries]()
    var countryName: String!
    var titleArray: [String] = ["Active", "Recovered", "Died"]
    var provinceCount = 0
   
    
    var activeCases = PieChartDataEntry(value: 0)
    var recoveredCases = PieChartDataEntry(value: 0)
    var deaths = PieChartDataEntry(value: 0)
    
    var numberOfCases = [PieChartDataEntry]()
   
    
    @IBOutlet var mainView: UIView!
    
   
    @IBOutlet weak var pieChartView: PieChartView!
    @IBOutlet weak var countryNameLbl: UILabel!
    @IBOutlet weak var provincesLbl: UILabel!
    @IBOutlet weak var provincesCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getPovinceCount()
        self.countryNameLbl.text = self.countryName
        let statsArray = self.getCountryStats()
        activeCases.value = Double(statsArray[0])
        recoveredCases.value = Double(statsArray[1])
        deaths.value = Double(statsArray[2])
//        pieChartView.chartDescription?.text = "Chandana"
//        pieChartView.chartDescription?.textColor = .systemPink
//       
//        activeCases.label = "Active cases"
//        recoveredCases.label = "Recovered Cases"
//        deaths.label = "Deaths"
        numberOfCases = [activeCases, recoveredCases, deaths]
        updatePieChart()
    }
    
    override func viewWillAppear(_ animated: Bool) {
       // self.statsTV.reloadData()
        self.provincesCV.reloadData()
        
    }
    
    @IBAction func doneBtnClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
//    @IBAction func onClickingSegmentCntrl(_ sender: Any) {
//        if segmentCntrl.selectedSegmentIndex == 0 {
//            addChild(loadPieChart)
//            mainView.addSubview(loadPieChart.view)
//        }
//        else {
//            addChild(loadBarChart)
//            mainView.addSubview(loadBarChart.view)
//        }
//
//    }
    
//    private lazy var loadPieChart: ProvincesViewController = {
//
//           let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
//           if #available(iOS 13.0, *) {
//               var pieChartController = storyboard.instantiateViewController(identifier: "ProvincesViewController") as! ProvincesViewController
//
//               self.addChild(pieChartController)
//               return pieChartController
//           } else {
//               return ProvincesViewController()
//           }
//
//       }()
//
//    private lazy var loadBarChart: barGraphViewController = {
//
//              let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
//              if #available(iOS 13.0, *) {
//                  var barChartController = storyboard.instantiateViewController(identifier: "barGraphViewController") as! barGraphViewController
//
//                  self.addChild(barChartController)
//                  return barChartController
//              } else {
//                  return barGraphViewController()
//              }
//
//          }()
//
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 3
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if let cell = statsTV.dequeueReusableCell(withIdentifier: "provincesCell", for: indexPath) as? statsTableViewCell {
//            let statsArray = self.getCountryStats()
//            cell.countLabel.text = "\(statsArray[indexPath.row])"
//            cell.titleLabel.text = "\(self.titleArray[indexPath.row])"
//
//            return cell
//        }
//        return UITableViewCell()
//    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.provinceCount
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = provincesCV.dequeueReusableCell(withReuseIdentifier: "ProvicesCollectionViewCell", for: indexPath) as? ProvicesCollectionViewCell {
            cell.layer.borderColor = CGColor.init(srgbRed: 0.000, green: 0.427, blue: 0.408, alpha: 1)
            cell.layer.borderWidth = 2
            cell.layer.cornerRadius = 10
            cell.layer.masksToBounds = true
            
            
            
                self.provincesCV.isHidden = false
                self.provincesLbl.isHidden = false
                cell.provinceTitle.text = self.countryList[indexPath.row].province
                if let confirmed = self.countryList[indexPath.row].stats?.confirmed, let recovered = self.countryList[indexPath.row].stats?.recovered, let died = self.countryList[indexPath.row].stats?.deaths {
                    cell.totalLabel.text = "Confirmed: \(confirmed)"
                    cell.recoveredLbl.text = "Recovered: \(recovered)"
                    cell.diedLbl.text = "Died: \(died)"
                    cell.activeLbl.text = "Active: \((confirmed)-(recovered)-(died))"
                }
            
            
            return cell
            
        }
        return UICollectionViewCell()
    }
    
    func getPovinceCount() {
        for country in self.countryList {
            if country.province != nil {
                self.provinceCount = self.provinceCount + 1
            }
        }
        if self.provinceCount > 0 {
            self.provincesCV.isHidden = false
            self.provincesLbl.isHidden = false
        }
        else {
            self.provincesCV.isHidden = true
            self.provincesLbl.isHidden = true
        }
    }
    
    func getCountryStats() -> [Int]{
        let localCountryArray = self.countryList
        var totalCases = Int()
        var recoveredCases = Int()
        var diedCases = Int()
        var activeCases = Int()
         var statsArray = [Int]()
        for element in localCountryArray {
            totalCases += (element.stats?.confirmed)!
            recoveredCases += (element.stats?.recovered)!
            diedCases += (element.stats?.deaths)!
            activeCases += totalCases - (recoveredCases + diedCases)
        }
        
        statsArray.append(activeCases)
        statsArray.append(recoveredCases)
        statsArray.append(diedCases)
        
        return statsArray
        
    }
    
    func updatePieChart() {
        
        let chartDataSet = PieChartDataSet(entries: numberOfCases, label: nil)
        let chartData =  PieChartData(dataSet: chartDataSet)
        
        let colors = [UIColor(cgColor: UIColor.orange.cgColor), UIColor(cgColor: UIColor.green.cgColor), UIColor(cgColor: UIColor.red.cgColor)]
        chartDataSet.colors = colors
        pieChartView.data = chartData
        
    }
    
    
}

