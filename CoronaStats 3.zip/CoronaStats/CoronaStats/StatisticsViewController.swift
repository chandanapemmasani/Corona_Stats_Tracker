//
//  StatisticsViewController.swift
//  CoronaStats
//
//  Created by Admin on 12/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit


class StatisticsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, ReportButton, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    
    @IBOutlet var viewUI: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var countriesTV: UITableView!
    @IBOutlet weak var todaysUpdatesCV: UICollectionView!
    
    @IBOutlet weak var lastUpdatedLbl: UILabel!
    @IBOutlet weak var collectionLayOut: UICollectionViewFlowLayout! //{
   
    var countriesList: [Countries]?
    // Abi
    var oneCountryList = [[Countries]]()
    var titleArray: [String] = ["Total", "Active", "Recovered", "Died", "NewCases"]
    var searchCountries: [String]!
    var countryNames: [String] = []
    var searching: Bool = false
    var todaysStats = [0, 0, 0, 0]
    weak var del: SpinnerDelegate!
  //  var localCountryArray: [Countries]!
  
    
    // barGraph viewController
     var jsonObj: [String: AnyObject] = [:]
    var singleDayStats: [NSDictionary] = []
    var selCountry = "Albania"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let textFieldInsideSearchBar = self.searchBar.value(forKey: "searchField") as? UITextField

        textFieldInsideSearchBar?.textColor = .white
        
        countriesTV.delegate = self
        countriesTV.dataSource = self
        self.viewUI.isHidden = false
        self.activityIndicator.isHidden = false
        viewUI.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        viewUI.isUserInteractionEnabled = false
        self.activityIndicator.startAnimating()
        self.fetchCoutriesData( completionHandler: { (countries, err)  in
            self.countriesList = countries
            //Abi
            self.generateCountryNamesArray()
            self.getTimeLbl()
          //  self.lastUpdatedLbl.text = "Last updated at \(self.getTime(countriesList![0].u, true))"
            DispatchQueue.main.async {
                
                self.activityIndicator.isHidden = true
                self.activityIndicator.stopAnimating()
                self.viewUI.isHidden = true
                self.viewUI.isUserInteractionEnabled = true
                      
                self.todaysUpdatesCV.reloadData()
                self.countriesTV.reloadData()
            }
            
        })
        
      //  fetchCoutriesPerDayData(countryName: selCountry)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.tabBarController?.navigationItem.title = ""
    }
    //Abi
    func generateCountryNamesArray() {
        
        var countrySet = Set<String>()
        for country in countriesList! {
            countrySet.insert(country.country!)
        }
        
        for name in countrySet.sorted() {
            let filterArray = countriesList?.filter({$0.country == name })
            oneCountryList.append(filterArray!)
        }
        self.getCountryNames()
    }
    
    
    func fetchCoutriesData(completionHandler: @escaping ([Countries]?, Error?) -> Void) {
        
        let urlString = "https://corona.lmao.ninja/v2/jhucsse"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            guard let data = data else {return}
            do {
                let countriesArray = try JSONDecoder().decode([Countries].self, from: data)
                
               
                                       
                completionHandler(countriesArray, err)
                print("success")
            } catch let jsonErr {
                print("chandana\(jsonErr)")
            }
        }.resume()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func getTodayStats(_ cell: inout StatisticsCollectionViewCell, _ indexPath: inout IndexPath ) -> StatisticsCollectionViewCell{
        var roundedValue: Double!
        if let countries = self.countriesList {
            for country in countries {
                todaysStats[0] = todaysStats[0] + (country.stats?.confirmed ?? 0)
                todaysStats[2] = todaysStats[2] + (country.stats?.recovered ?? 0)
                todaysStats[3] = todaysStats[3] + (country.stats?.deaths ?? 0)
            }
            todaysStats[1] = todaysStats[0] - (todaysStats[2] + todaysStats[3])
        }
        
        
        if todaysStats[indexPath.row] >= 1000 && todaysStats[indexPath.row] < 1000000 {
            roundedValue = Double(todaysStats[indexPath.row])
            roundedValue = roundedValue/1000
            roundedValue = Double(round(100*roundedValue)/100)
            cell.valueLbl.text = "\(roundedValue!)K"
        }
        else if todaysStats[indexPath.row] >= 1000000 && todaysStats[indexPath.row] < 10000000 {
            roundedValue = Double(todaysStats[indexPath.row])
            roundedValue = roundedValue/1000000
            roundedValue = Double(round(100*roundedValue)/100)
            cell.valueLbl.text = "\(roundedValue!)M"
        }
        else {
            cell.valueLbl.text = "\(todaysStats[indexPath.row])"
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        todaysStats = [0, 0, 0, 0]
        var indexpath = indexPath
        if var cell = todaysUpdatesCV.dequeueReusableCell(withReuseIdentifier: "todayCell", for: indexPath) as? StatisticsCollectionViewCell {
            cell.layer.borderColor = CGColor.init(srgbRed: 0.000, green: 0.427, blue: 0.408, alpha: 1)
            cell.layer.borderWidth = 2
            cell.layer.cornerRadius = 10
            cell.layer.masksToBounds = true
            //            cell.maxWidthTitle = collectionView.bounds.width
            //            cell.maxWidthValue = collectionView.bounds.width
            cell.titleLbl.text = self.titleArray[indexPath.row]
            cell = getTodayStats(&cell, &indexpath)
//            if todaysStats[indexPath.row] >= 1000 && todaysStats[indexPath.row] < 1000000 {
//
//            }
//             else if todaysStats[indexPath.row] >= 1000000 && todaysStats[indexPath.row] < 10000000 {
//            }
//             else {
//            }
            return cell
        }
        return UICollectionViewCell()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return searchCountries.count
        }
        else {
            return oneCountryList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = countriesTV.dequeueReusableCell(withIdentifier: "countryCell", for: indexPath) as? CountriesTableViewCell {
            let localCountryArray = oneCountryList[indexPath.row]
            var countryName = String()
            var confirmedCases = Int()
            
            if searching {
                for countries in oneCountryList {
                    if self.searchCountries[indexPath.row] == countries[0].country {
                        cell.countryName.text = countries[0].country
                        for country in countries {
                            
                            confirmedCases += (country.stats?.confirmed)!
                        }
                        cell.confirmedCases.text = "\(confirmedCases)"
                    }
                }
                return cell
            }
                
            else {
                
                for element in localCountryArray {
                    countryName = element.country!
                    confirmedCases += (element.stats?.confirmed)!
                    
                }
                cell.countryName.text = countryName
                cell.confirmedCases.text = "\(confirmedCases)"
                
                return cell
            }
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let controller = storyboard.instantiateViewController(withIdentifier: "ProvincesViewController") as? ProvincesViewController else {
            return
        }
        let cell = countriesTV.cellForRow(at: indexPath) as? CountriesTableViewCell
        controller.countryName = cell?.countryName.text
        if searching {
            let countryName = searchCountries[indexPath.row]
            for country in oneCountryList {
                if country[0].country == countryName {
                    controller.countryList = country
                }
            }
             
        }else {
            controller.countryList = oneCountryList[indexPath.row]
        }
        
       // self.navigationController?.pushViewController(controller, animated: true)
        self.present(controller, animated: true, completion: nil)
    }
    
    func getCountryNames() {
        
        for country in oneCountryList {
            countryNames.append(country[0].country ?? "")
        }
       
        if let tbc = self.tabBarController as? CommonTabBarController {
            tbc.countriesArray = countryNames
        }
         
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchCountries = self.countryNames.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
         searching = true
         self.countriesTV.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        self.countriesTV.reloadData()
    }
    //    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //        return oneCountryList.count
    //    }
    //
    //    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    //        if let cell = countriesCollectinView.dequeueReusableCell(withReuseIdentifier: "StatisticsCollectionViewCell", for: indexPath) as? StatisticsCollectionViewCell{
    //            //Abi
    //            let localCountryArray = oneCountryList[indexPath.row]
    //
    //            var countryName = String()
    //            var totalCases = Int()
    //            var recoveredCases = Int()
    //            var diedCases = Int()
    //            var activeCases = Int()
    //
    //            for element in localCountryArray {
    //                countryName = element.country!
    //                totalCases += (element.stats?.confirmed)!
    //                recoveredCases += (element.stats?.recovered)!
    //                diedCases += (element.stats?.deaths)!
    //                activeCases += totalCases - (recoveredCases + diedCases)
    //            }
    //            cell.countryLbl.text = countryName
    //            cell.totalLbl.text = "Total: \(totalCases)"
    //            cell.recoveredLbl.text = "Recovered: \(recoveredCases)"
    //            cell.diedLbl.text = "Died: \(diedCases)"
    //            cell.activeLbl.text = "Active: \(activeCases)"
    //
    //            return cell
    //        }
    //        return UICollectionViewCell()
    //    }
    //
    
//    private func getTime(_ dateString: String, _ time: Bool) -> String {
//        var timeString = dateString
//        if let range = dateString.range(of: "T") {
//            if time {
//                timeString = dateString.substring(from: range.upperBound)
//                timeString = String(timeString.prefix(5))
//            }
//            else {
//                timeString = String(timeString.prefix(10))
//            }
//        }
//        return timeString
//    }

    func configNavBar() {
        self.navigationController?.navigationBar.backgroundColor = UIColor.black
        self.navigationController?.navigationBar.tintColor = UIColor.white
        // self.navigationController?. = UIColor.black
        self.navigationItem.rightBarButtonItem =  UIBarButtonItem(image: UIImage(named: "ReportCase"), style: .plain, target: self, action: #selector(self.reportNewCaseBtn))
        
        //  let navTitleView = UIView(frame: CGRect(x: 20, y: 0, width: 150, height: 50))
        
        let titleLabel = UILabel(frame: CGRect(x: 2, y: 10, width: 354, height: 22))
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.textAlignment = NSTextAlignment.left
        titleLabel.textColor = .white
        titleLabel.font = UIFont(name: "HelveticaNeue-Bold",
                                 size: 25)
        titleLabel.text = "Global Covid-19"
        //  navTitleView.addSubview(titleLabel)
        self.navigationController?.navigationBar.addSubview(titleLabel)
        // self.navigationController?.navigationBar.heightAnchor = 50
        //  self.navigationItem.titleView = navTitleView
    }
    
    @objc func reportNewCaseBtn() {
        
    }
    
    func getTimeLbl() {
        if let countries = self.countriesList {
            var timeString = countries[0].updatedAt
            let dateString = String((timeString?.prefix(10))!)
            let convertedString = self.dateWithShortString(dateString)
             let formatter = DateFormatter()
            formatter.dateFormat = "d MMM"
            
            if let range = timeString?.range(of: " ") {

                var convertedString = timeString?.substring(from: range.upperBound)
                timeString = String((convertedString?.prefix(5))!)

            }
            DispatchQueue.main.async {

             self.lastUpdatedLbl.text = "Last updated at \(formatter.string(from: convertedString!) + " \(timeString!)") AM"
            }
            
        }
    }
    
    func dateWithShortString(_ dateString: String) -> Date?
     {
         let formatter = DateFormatter()
         formatter.dateFormat = "yyyy-MM-dd"
         if let date = formatter.date(from: dateString)
         {
             return date
         }
         return nil
     }
    
    func fetchCoutriesPerDayData(countryName: String) {
               
//        let bgVC = barGraphViewController()
               let urlString = "https://pomber.github.io/covid19/timeseries.json"
            let url = URL(string: urlString)
            URLSession.shared.dataTask(with: url!){ (data, response, error) in
                if error != nil {
                    print("error")
                }
                else{
                    do {
                     //   self.del.spinnerAnimation(true)
                        self.jsonObj = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]
                        let myData = self.jsonObj[countryName] as! NSArray
                        
                        for index in 0..<myData.count {
                            self.singleDayStats.append(myData[index] as! NSDictionary)
                        }
                        self.getCasesPerMonth()
                        DispatchQueue.main.async {
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            self.viewUI.isHidden = true
                            self.viewUI.isUserInteractionEnabled = true
                        }
                        
                     //   self.del.spinnerAnimation(false)
                       // MacawChartView.playAnimations()
                    }catch let error as NSError {
                        print(error)
                    }
                        
                }
                   
                
            }.resume()
    }
    func getCasesPerMonth() {
        var caseCountPerMonth = [Int]()
        let todayDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM"
        let currentMonth = dateFormatter.string(from: todayDate)
        dateFormatter.dateFormat = "dd"
        let currentday = dateFormatter.string(from: todayDate)
        if let curMonth = Int(currentMonth) {
            var month: Int!
            let maxNoOfBars = 6
            if curMonth < (maxNoOfBars + 1) {
                month = 1
            }
            else {
                
                month = curMonth - maxNoOfBars + 1
            }
            
            while month < (curMonth + 1) {
                var confirmedCount = 0
                for index in 0..<self.singleDayStats.count {
                    let dateVariable = self.singleDayStats[index]["date"] as! String
                    if let monthVar = dateVariable.range(of: "(?<=-)[^-]+", options: .regularExpression) {
                        if dateVariable.substring(with: monthVar) == String(month) {
                            if month < curMonth {
                                
                                
                                let nextMonthDate = self.singleDayStats[index + 1]["date"] as! String
                                if let nextmonthVar = nextMonthDate.range(of: "(?<=-)[^-]+", options: .regularExpression) {
                                    if nextMonthDate.substring(with: nextmonthVar) != String(month) {
                                        confirmedCount = self.singleDayStats[index]["confirmed"] as! Int
                                    }
                                    
                                }
                            }
                            else {
                                dateFormatter.dateFormat = "dd"
                                let today = dateFormatter.string(from: todayDate)
                                if let range = dateVariable.range(of: "-\(month!)-") {
                                    let day = dateVariable[range.upperBound...]
                                    if Int(day)! == Int(today)! - 1 || day == today || Int(day)! == Int(today)! - 2{
                                        confirmedCount = self.singleDayStats[index]["confirmed"] as! Int
                                    }
                                }
                            }
                        }
                       
                    }
                }
                
                caseCountPerMonth.append(confirmedCount)
                month = month + 1
                
            }
            self.assignBarData(caseCountPerMonth)
        }
    }
    
    func assignBarData(_ caseCounts: [Int]) {
        MacawChartView.maxValue = caseCounts.max() ?? 0
        
        MacawChartView.monthsBars.append(ChartFields(month: "Jan", casecount: Double(caseCounts[0])))
        MacawChartView.monthsBars.append(ChartFields(month: "Feb", casecount: Double(caseCounts[1])))
        MacawChartView.monthsBars.append(ChartFields(month: "mar", casecount: Double(caseCounts[2])))
        MacawChartView.monthsBars.append(ChartFields(month: "apr", casecount: Double(caseCounts[3])))
        MacawChartView.monthsBars.append(ChartFields(month: "may", casecount: Double(caseCounts[4])))
        MacawChartView.monthsBars.append(ChartFields(month: "June", casecount: Double(caseCounts[5])))
        MacawChartView.adjustedData = MacawChartView.monthsBars.map({ $0.casecount})
               
//               for index in 0..<caseCounts.count {
//                MacawChartView.monthsBars.append(ChartFields(month: "Jan", casecount: Double(caseCounts[index])))
//               }
//               let firstMonth = ChartFields(month: "Jan", casecount: 999996)
//               let secMonth = ChartFields(month: "Feb", casecount: 833330)
              
           }
        
    
}
