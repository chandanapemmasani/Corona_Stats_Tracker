//
//  barGraphViewController.swift
//  CoronaStats
//
//  Created by Admin on 17/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit
import Charts
import SwiftCharts

protocol SpinnerDelegate: class {
    
    func spinnerAnimation(_ animate: Bool)
}

class BarGraphViewController: UIViewController, BarGraph  {
  
    
    @IBOutlet weak var countrySelected: UIButton!
   
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    var confirmCountArray = [Double]()
    var chartView: BarsChart!
    var maxinMonth: Double!
    var mininMointh: Double!
    var firstLastDays = [Int: String]()
    var temp = 0

    
    var jsonObj: [String: AnyObject] = [:]
  //  var countryNames = [String]()
    var singleDayStats: [NSDictionary] = []
    
   // var barGraphCountryCount: Int = 0
   // var monthCount: [Int]!
   // var monthsArray = [BarChartDataEntry(x: 0.0, yValues: [0.0])]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.spinner.color = .white
        countrySelected.setTitle("Afghanistan", for: .normal)
        fetchCoutriesPerDayData("Afghanistan")
      //  barGraphIndicator.startAnimating()
       // MacawChartView.playAnimations()
//        barChartView.contentMode = .scaleAspectFit
//        barChartView.backgroundColor = .black
       // barChart.delegate = self
      //  fetchCoutriesPerDayData()
       // self.barChartView.reloadInputViews()
    }
    
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//        MacawChartView.playAnimations()
//    }
   // override func viewWillAppear(_ animated: Bool) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        guard let controller = storyboard.instantiateViewController(withIdentifier: "barGraphViewController") as? barGraphViewController else {
//            return
//        }
//        _ = controller.view
       
  //  }
 
    
    @IBAction func countryBtnTapped(_ sender: Any) {
        
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                guard let controller = storyboard.instantiateViewController(withIdentifier: "countriesViewController") as? countriesViewController else {
                    return
                }
        if let tbc = self.tabBarController as? CommonTabBarController {
             controller.allCountries = tbc.countriesArray
        }
        controller.barChartDel = self
        self.present(controller, animated: true, completion: nil)
        
    }
    
    func getBarChartData(country: String) {
        countrySelected.titleLabel?.text = country
        self.fetchCoutriesPerDayData(country)
      }
      
     
    
    //        barChart.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
//        barChart.center = view.center
//        view.addSubview(barChart)
//
//        var entries = [BarChartDataEntry]()
//
//        for i in 0..<5 {
//            entries.append(BarChartDataEntry(x: Double(i), y: Double(i)))
//        }
//        let set = BarChartDataSet(entries: entries)
//        set.colors = ChartColorTemplates.pastel()
//        let data = BarChartData(dataSet: set)
//        barChart.data = data
  //  }
    
//    func spinnerAnimation(_ animate: Bool) {
//        if animate {
//            barGraphIndicator.startAnimating()
//        }
//        else {
//            barGraphIndicator.stopAnimating()
//        }
//    }
   
    func fetchCoutriesPerDayData(_ countryName: String) {
        temp = temp + 1
        if temp > 1{
            self.view.subviews[2].removeFromSuperview()
        }
        countrySelected.setTitle(countryName, for: .normal)
        self.spinner.isHidden = false
        self.spinner.startAnimating()
           let urlString = "https://pomber.github.io/covid19/timeseries.json"
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with: url!){ (data, response, error) in
            if error != nil {
                print("error")
            }
            else{
                do {
                    self.jsonObj = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]
                    let myData = self.jsonObj[countryName] as! NSArray

                    
                    for index in 0..<myData.count {
                        self.singleDayStats.append(myData[index] as! NSDictionary)

//                        totalCount = self.dayCount[index]["confirmed"] as! Int
//                        self.barGraphCountryCount = self.barGraphCountryCount + totalCount
                    }
          //          self.getCasesPerMonth()
                    self.getConfirmedcasesDaywise()

                }catch let error as NSError {
                    print(error)
                }

            }


        }.resume()
}
    func getConfirmedcasesDaywise(){
        
        let startDay = self.singleDayStats.count - 30
        
        for index in startDay..<self.singleDayStats.count {
            if index == startDay {
                firstLastDays[0] = self.singleDayStats[index - 1]["date"] as? String
                
            }
            else if index == self.singleDayStats.count - 1 {
                firstLastDays[28] = self.singleDayStats[index - 1]["date"] as? String
            }
            if startDay != 0 {
                let prevDay = self.singleDayStats[index - 1]["confirmed"] as! Double
                let currDay = self.singleDayStats[index]["confirmed"] as! Double
                if (currDay - prevDay) >= 0 {
                    confirmCountArray.append((currDay - prevDay))
                }
                
            }
        }
        maxinMonth = confirmCountArray.max()
        mininMointh = confirmCountArray.min()
      // temp = temp + 1
        configBars(temp)
    }
    
    func configBars(_ temp: Int) {
        DispatchQueue.main.async {
            
//            if temp > 1{
//            self.view.subviews[2].removeFromSuperview()
//            }
//            .forEach({ $0.removeFromSuperview() })
//            self.view.addSubview(self.countrySelected)
        self.chartView = nil
        let chartConfig = BarsChartConfig(
            valsAxisConfig: ChartAxisConfig(from: 0, to: self.maxinMonth, by: Double((self.maxinMonth - self.mininMointh)/10) ))
        let frame = CGRect(x: 0, y: 200, width: self.view.frame.width, height: 500)
      //  let graphTuple: (String, Double)?
        var barChartDict = [(String, Double)]()
            for index in 0..<self.confirmCountArray.count {
                if index == 0 || index == self.confirmCountArray.count - 2 {
                    let dateString = self.firstLastDays[index]!
                   // let dateString = self.getTime(date, false)
                    let dateSTA = Date.dateWithShortString(dateString)
                    if let sta = dateSTA {
                         let formatter = DateFormatter()
                        formatter.dateFormat = "d MMM"
                       let dayMonth = formatter.string(from: sta)
                    barChartDict.append(("\(dayMonth)", self.confirmCountArray[index]))
                    }
                  //  let bite = "STD \(self.getTime(date, true))"
                    
                    
                    
                    
                    
                    
                    
                    
                }
                else {
                barChartDict.append(("", self.confirmCountArray[index]))
                }
                print(self.confirmCountArray[index])
                
           // barChartDict["\(index)"] = confirmCountArray[index]
        }
        let chart = BarsChart(
            frame: frame,
            chartConfig: chartConfig,
            xTitle: "Days",
            yTitle: "Count",
            bars: barChartDict,
//            bars: [
//                ("jan", arr[0]),
//                ("feb", arr[1]),
//                ("mar", arr[2]),
//                ("apr", arr[3]),
//                ("may",  arr[4])
//            ],
            color: UIColor.white,
            barWidth: 3
        )
            self.spinner.isHidden = true
            self.spinner.stopAnimating()
        self.view.addSubview(chart.view)
        self.chartView = chart
            self.confirmCountArray.removeAll()
            
        }
    }
    
//    if let scheduledDate = updatedFlights[alternateFlightIndex[indexpath]].departureInfo?.scheduledTimeLocal {
//        let dateString = self.getTime(scheduledDate, false)
//        let dateSTA = Date.dateWithShortString(dateString)
//        if let sta = dateSTA {
//            formatter.dateFormat = "d MMM"
//            cell.altFlightDepDate.text = formatter.string(from: sta)
//        }
//        cell.altFlightSTD.text = "STD \(self.getTime(scheduledDate, true))"
  //  }
    func getTime(_ dateString: String, _ time: Bool) -> String {
              var timeString = dateString
              if let range = dateString.range(of: "T") {
                  if time {
                      timeString = dateString.substring(from: range.upperBound)
                      timeString = String(timeString.prefix(5))
                  }
                  else {
                      timeString = String(timeString.prefix(10))
                  }
               }
           return timeString
       }
     
    
}
extension Date {
    
   static func dateWithShortString(_ dateString: String) -> Date?
     {
         let formatter = DateFormatter()
         formatter.dateFormat = "yyyy-MM-dd"
         if let date = formatter.date(from: dateString)
         {
             return date
         }
         return nil
     }

}
