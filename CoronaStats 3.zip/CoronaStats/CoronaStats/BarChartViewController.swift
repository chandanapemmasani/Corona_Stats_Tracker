//
//  BarChartViewController.swift
//  CoronaStats
//
//  Created by Admin on 09/06/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit
import SwiftCharts

class BarChartViewController: UIViewController {

    var chartView: BarsChart!
    var arrnum: [Double] = [0,0,0,0,0]
    @IBOutlet weak var tap: UIButton!
    
    @IBAction func onTap(_ sender: Any) {
        arrnum.removeAll()
        arrnum.append(50)
        arrnum.append(100)
        arrnum.append(300)
        arrnum.append(200)
        arrnum.append(100)
        configBars(arrnum)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        arrnum.removeAll()
        arrnum.append(100)
        arrnum.append(200)
        arrnum.append(500)
        arrnum.append(600)
        arrnum.append(300)
        configBars(arrnum)
    }
    
    func configBars(_ arr: [Double]) {
        
        let chartConfig = BarsChartConfig(
            valsAxisConfig: ChartAxisConfig(from: 0, to: 1000, by: 100) )
        let frame = CGRect(x: 0, y: 270, width: self.view.frame.width, height: 450)
        let chart = BarsChart(
            frame: frame,
            chartConfig: chartConfig,
            xTitle: "Months",
            yTitle: "Count",
            bars: [
                ("jan", arr[0]),
                ("feb", arr[1]),
                ("mar", arr[2]),
                ("apr", arr[3]),
                ("may",  arr[4])
            ],
            color: UIColor.white,
            barWidth: 10
        )
        self.view.addSubview(chart.view)
        self.chartView = chart
        
    }

}
