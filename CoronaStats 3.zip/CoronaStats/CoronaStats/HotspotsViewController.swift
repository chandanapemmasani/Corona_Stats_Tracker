//
//  HotspotsViewController.swift
//  CoronaStats
//
//  Created by Admin on 13/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit
@objc protocol ReportButton: class {
        func reportNewCaseBtn()
}
class HotspotsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   

    @IBOutlet weak var hotSpotTableview: UITableView!
    weak var reportDel: ReportButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hotSpotTableview.tableFooterView = UIView()
        self.setNavBar()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let controller = storyboard.instantiateViewController(withIdentifier: "StatisticsViewController") as? StatisticsViewController else {
            return
        }
        self.reportDel = controller
    }
    
    func setNavBar() {
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationItem.rightBarButtonItem =  UIBarButtonItem(image: UIImage(named: "ReportCase"), style: .plain, target: self, action: #selector(self.reportDel?.reportNewCaseBtn))
        
        let navTitleView = UIView(frame: CGRect(x: 20, y: 0, width: 150, height: 50))
        
        let titleLabel = UILabel(frame: CGRect(x: 0, y: 10, width: 154, height: 22))
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.textAlignment = NSTextAlignment.center
        titleLabel.textColor = .black
        titleLabel.font = UIFont(name: "Helvetica",
                                 size: 17)
        titleLabel.text = "HotSpots"
        navTitleView.addSubview(titleLabel)
        self.navigationItem.titleView = navTitleView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8 
      }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                
        if let cell = hotSpotTableview.dequeueReusableCell(withIdentifier: "HotspotTableviewCell", for: indexPath) as? HotspotTableviewCell {
                cell.backgroundColor = UIColor.opaqueSeparator
                  return cell
              }
              return UITableViewCell()
       }
       
 
}
