//
//  ProvicesCollectionViewCell.swift
//  CoronaStats
//
//  Created by Admin on 02/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit

class ProvicesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var provinceTitle: UILabel!
    
    @IBOutlet weak var totalLabel: UILabel!
    
    @IBOutlet weak var activeLbl: UILabel!
    
    @IBOutlet weak var recoveredLbl: UILabel!
    @IBOutlet weak var diedLbl: UILabel!
}
