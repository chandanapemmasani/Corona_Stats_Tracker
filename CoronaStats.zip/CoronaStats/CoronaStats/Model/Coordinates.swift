//
//  Coordinates.swift
//  CoronaStats
//
//  Created by Admin on 17/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation
public class Coordinates: Codable {
    
   public var latitude: String?
   public var longitude: String?

    private enum CodingKeys: String, CodingKey {
               case latitude
               case longitude
           }
    public required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

               self.latitude = try container.decodeIfPresent(String.self, forKey: .latitude)
               self.longitude = try container.decodeIfPresent(String.self, forKey: .longitude)

           }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
            if latitude != nil {
                    try container.encode(latitude, forKey: .latitude)
            }
            if longitude != nil {
                try container.encode(longitude, forKey: .longitude)
            }
        }
}
