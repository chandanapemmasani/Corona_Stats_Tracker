//
//  ProvincesViewController.swift
//  CoronaStats
//
//  Created by Admin on 01/05/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit

class ProvincesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var countryList = [Countries]()
    var countryName: String!
    var titleArray: [String] = ["Active", "Recovered", "Died"]
    var provinceCount = 0
    @IBOutlet weak var statsTV: UITableView!
    
    @IBOutlet weak var countryNameLbl: UILabel!
    @IBOutlet weak var provincesLbl: UILabel!
    @IBOutlet weak var provincesCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getPovinceCount()
        self.countryNameLbl.text = self.countryName
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.statsTV.reloadData()
        self.provincesCV.reloadData()
        
    }
    
    @IBAction func doneBtnClicked(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = statsTV.dequeueReusableCell(withIdentifier: "provincesCell", for: indexPath) as? statsTableViewCell {
            let statsArray = self.getCountryStats()
            cell.countLabel.text = "\(statsArray[indexPath.row])"
            cell.titleLabel.text = "\(self.titleArray[indexPath.row])"
            
            return cell
        }
        return UITableViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.provinceCount
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = provincesCV.dequeueReusableCell(withReuseIdentifier: "ProvicesCollectionViewCell", for: indexPath) as? ProvicesCollectionViewCell {
            cell.layer.borderColor = CGColor.init(srgbRed: 0.000, green: 0.427, blue: 0.408, alpha: 1)
            cell.layer.borderWidth = 2
            cell.layer.cornerRadius = 10
            cell.layer.masksToBounds = true
            
            
            
                self.provincesCV.isHidden = false
                self.provincesLbl.isHidden = false
                cell.provinceTitle.text = self.countryList[indexPath.row].province
                if let confirmed = self.countryList[indexPath.row].stats?.confirmed, let recovered = self.countryList[indexPath.row].stats?.recovered, let died = self.countryList[indexPath.row].stats?.deaths {
                    cell.totalLabel.text = "Confirmed: \(confirmed)"
                    cell.recoveredLbl.text = "Recovered: \(recovered)"
                    cell.diedLbl.text = "Died: \(died)"
                    cell.activeLbl.text = "Active: \((confirmed)-(recovered)-(died))"
                }
            
            
            return cell
            
        }
        return UICollectionViewCell()
    }
    
    func getPovinceCount() {
        for country in self.countryList {
            if country.province != nil {
                self.provinceCount = self.provinceCount + 1
            }
        }
        if self.provinceCount > 0 {
            self.provincesCV.isHidden = false
            self.provincesLbl.isHidden = false
        }
        else {
            self.provincesCV.isHidden = true
            self.provincesLbl.isHidden = true
        }
    }
    
    func getCountryStats() -> [Int]{
        let localCountryArray = self.countryList
        var totalCases = Int()
        var recoveredCases = Int()
        var diedCases = Int()
        var activeCases = Int()
        var statsArray = [Int]()
        for element in localCountryArray {
            totalCases += (element.stats?.confirmed)!
            recoveredCases += (element.stats?.recovered)!
            diedCases += (element.stats?.deaths)!
            activeCases += totalCases - (recoveredCases + diedCases)
        }
        
        statsArray.append(activeCases)
        statsArray.append(recoveredCases)
        statsArray.append(diedCases)
        
        return statsArray
        
    }
    
    
}

