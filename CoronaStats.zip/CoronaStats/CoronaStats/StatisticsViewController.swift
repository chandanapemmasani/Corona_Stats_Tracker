//
//  StatisticsViewController.swift
//  CoronaStats
//
//  Created by Admin on 12/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit


class StatisticsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, ReportButton, UITableViewDelegate, UITableViewDataSource {
    
    
    
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var countriesTV: UITableView!
    @IBOutlet weak var todaysUpdatesCV: UICollectionView!
    
    @IBOutlet weak var lastUpdatedLbl: UILabel!
    @IBOutlet weak var collectionLayOut: UICollectionViewFlowLayout! //{
    //        didSet {
    //            collectionLayOut.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
    //        }
    //    }
    //
    var countriesList: [Countries]?
    // Abi
    var oneCountryList = [[Countries]]()
    var titleArray: [String] = ["Total", "Active", "Recovered", "Died", "NewCases"]
  //  var localCountryArray: [Countries]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countriesTV.delegate = self
        countriesTV.dataSource = self
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        
        self.fetchCoutriesData( completionHandler: { (countries, err)  in
            self.countriesList = countries
            //Abi
            self.generateCountryNamesArray()
            self.getTimeLbl()
          //  self.lastUpdatedLbl.text = "Last updated at \(self.getTime(countriesList![0].u, true))"
            DispatchQueue.main.async {
                self.activityIndicator.isHidden = true
                self.activityIndicator.stopAnimating()
                self.todaysUpdatesCV.reloadData()
                self.countriesTV.reloadData()
            }
            
        })
        
        //        let nib = UINib(nibName: "myCustomCell", bundle: nil)
        //        todaysUpdatesCV.register(nib, forCellWithReuseIdentifier: "reuseId")
        //
        //        // IMPORTANT: this is the key to make your cells auto-sizing
        //        if let collectionViewLayout = todaysUpdatesCV.collectionViewLayout as? UICollectionViewFlowLayout {
        //            collectionViewLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        //        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.tabBarController?.navigationItem.title = ""
    }
    //Abi
    func generateCountryNamesArray() {
        
        var countrySet = Set<String>()
        for country in countriesList! {
            countrySet.insert(country.country!)
        }
        
        for name in countrySet.sorted() {
            let filterArray = countriesList?.filter({$0.country == name })
            oneCountryList.append(filterArray!)
        }
        
    }
    
    
    func fetchCoutriesData(completionHandler: @escaping ([Countries]?, Error?) -> Void) {
        
        let urlString = "https://corona.lmao.ninja/v2/jhucsse"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            guard let data = data else {return}
            do {
                let countriesArray = try JSONDecoder().decode([Countries].self, from: data)
                
                completionHandler(countriesArray, err)
            } catch let jsonErr {
                print(jsonErr)
            }
        }.resume()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = todaysUpdatesCV.dequeueReusableCell(withReuseIdentifier: "todayCell", for: indexPath) as? StatisticsCollectionViewCell {
            cell.layer.borderColor = CGColor.init(srgbRed: 0.000, green: 0.427, blue: 0.408, alpha: 1)
            cell.layer.borderWidth = 2
            cell.layer.cornerRadius = 10
            cell.layer.masksToBounds = true
            //            cell.maxWidthTitle = collectionView.bounds.width
            //            cell.maxWidthValue = collectionView.bounds.width
            
            cell.titleLbl.text = self.titleArray[indexPath.row]
            return cell
        }
        return UICollectionViewCell()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return oneCountryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = countriesTV.dequeueReusableCell(withIdentifier: "countryCell", for: indexPath) as? CountriesTableViewCell {
            
            let localCountryArray = oneCountryList[indexPath.row]
            
            var countryName = String()
            var confirmedCases = Int()
            
            for element in localCountryArray {
                countryName = element.country!
                confirmedCases += (element.stats?.confirmed)!
                
            }
            cell.countryName.text = countryName
            cell.confirmedCases.text = "\(confirmedCases)"
            
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let controller = storyboard.instantiateViewController(withIdentifier: "ProvincesViewController") as? ProvincesViewController else {
            return
        }
        let cell = countriesTV.cellForRow(at: indexPath) as? CountriesTableViewCell
        controller.countryName = cell?.countryName.text
        controller.countryList = oneCountryList[indexPath.row]
       // self.navigationController?.pushViewController(controller, animated: true)
        self.present(controller, animated: true, completion: nil)
        
        
    }
    //    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //        return oneCountryList.count
    //    }
    //
    //    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    //        if let cell = countriesCollectinView.dequeueReusableCell(withReuseIdentifier: "StatisticsCollectionViewCell", for: indexPath) as? StatisticsCollectionViewCell{
    //            //Abi
    //            let localCountryArray = oneCountryList[indexPath.row]
    //
    //            var countryName = String()
    //            var totalCases = Int()
    //            var recoveredCases = Int()
    //            var diedCases = Int()
    //            var activeCases = Int()
    //
    //            for element in localCountryArray {
    //                countryName = element.country!
    //                totalCases += (element.stats?.confirmed)!
    //                recoveredCases += (element.stats?.recovered)!
    //                diedCases += (element.stats?.deaths)!
    //                activeCases += totalCases - (recoveredCases + diedCases)
    //            }
    //            cell.countryLbl.text = countryName
    //            cell.totalLbl.text = "Total: \(totalCases)"
    //            cell.recoveredLbl.text = "Recovered: \(recoveredCases)"
    //            cell.diedLbl.text = "Died: \(diedCases)"
    //            cell.activeLbl.text = "Active: \(activeCases)"
    //
    //            return cell
    //        }
    //        return UICollectionViewCell()
    //    }
    //
    
    private func getTime(_ dateString: String, _ time: Bool) -> String {
        var timeString = dateString
        if let range = dateString.range(of: "T") {
            if time {
                timeString = dateString.substring(from: range.upperBound)
                timeString = String(timeString.prefix(5))
            }
            else {
                timeString = String(timeString.prefix(10))
            }
        }
        return timeString
    }

    func configNavBar() {
        self.navigationController?.navigationBar.backgroundColor = UIColor.black
        self.navigationController?.navigationBar.tintColor = UIColor.white
        // self.navigationController?. = UIColor.black
        self.navigationItem.rightBarButtonItem =  UIBarButtonItem(image: UIImage(named: "ReportCase"), style: .plain, target: self, action: #selector(self.reportNewCaseBtn))
        
        //  let navTitleView = UIView(frame: CGRect(x: 20, y: 0, width: 150, height: 50))
        
        let titleLabel = UILabel(frame: CGRect(x: 2, y: 10, width: 354, height: 22))
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.textAlignment = NSTextAlignment.left
        titleLabel.textColor = .white
        titleLabel.font = UIFont(name: "HelveticaNeue-Bold",
                                 size: 25)
        titleLabel.text = "Global Covid-19"
        //  navTitleView.addSubview(titleLabel)
        self.navigationController?.navigationBar.addSubview(titleLabel)
        // self.navigationController?.navigationBar.heightAnchor = 50
        //  self.navigationItem.titleView = navTitleView
    }
    
    @objc func reportNewCaseBtn() {
        
    }
    
    func getTimeLbl() {
        if let countries = self.countriesList {
            var timeString = countries[0].updatedAt
            let dateString = String((timeString?.prefix(10))!)
            let convertedString = self.dateWithShortString(dateString)
             let formatter = DateFormatter()
            formatter.dateFormat = "d MMM"
            
            if let range = timeString?.range(of: " ") {

                var convertedString = timeString?.substring(from: range.upperBound)
                timeString = String((convertedString?.prefix(5))!)

            }
            DispatchQueue.main.async {

             self.lastUpdatedLbl.text = "Last updated at \(formatter.string(from: convertedString!) + " \(timeString!)")"
            }
            
        }
    }
    
    func dateWithShortString(_ dateString: String) -> Date?
     {
         let formatter = DateFormatter()
         formatter.dateFormat = "yyyy-MM-dd"
         if let date = formatter.date(from: dateString)
         {
             return date
         }
         return nil
     }
}
