//
//  StatisticsCollectionViewCell.swift
//  CoronaStats
//
//  Created by Admin on 12/04/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import UIKit

class StatisticsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var valueLbl: UILabel!
    @IBOutlet private var maxWidthConstraintTitleLbl: NSLayoutConstraint! {
        didSet {
            maxWidthConstraintTitleLbl.isActive = false
        }
    }
//    var maxWidthTitle: CGFloat? = nil {
//        didSet {
//            guard let maxWidth = maxWidthTitle else {
//                return
//            }
//            maxWidthConstraintTitleLbl.isActive = true
//            maxWidthConstraintTitleLbl.constant = maxWidth
//        }
//    }
    @IBOutlet private var maxWidthConstraintValueLbl: NSLayoutConstraint! {
           didSet {
               maxWidthConstraintValueLbl.isActive = false
           }
       }
//       var maxWidthValue: CGFloat? = nil {
//           didSet {
//               guard let maxWidth = maxWidthValue else {
//                   return
//               }
//               maxWidthConstraintValueLbl.isActive = true
//               maxWidthConstraintValueLbl.constant = maxWidth
//           }
//       }
    override func awakeFromNib() {
           super.awakeFromNib()
           
           // Add width constraint if you want dynamic height
//           mainView.translatesAutoresizingMaskIntoConstraints = false
//           mainView.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.size.width-100).isActive = true
       }
//    override func awakeFromNib() {
//        super.awakeFromNib()
//
//        contentView.translatesAutoresizingMaskIntoConstraints = false
//
//            NSLayoutConstraint.activate([
//                contentView.leftAnchor.constraint(equalTo: leftAnchor),
//                contentView.rightAnchor.constraint(equalTo: rightAnchor),
//                contentView.topAnchor.constraint(equalTo: topAnchor),
//                contentView.bottomAnchor.constraint(equalTo: bottomAnchor)
//            ])
//    }
    
}
